//package com.home.insurance.controller;
//
//import java.util.List;
//
//import javax.management.ServiceNotFoundException;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.home.insurance.bean.MaritalStatus;
//import com.home.insurance.exception.LobNotfoundException;
//import com.home.insurance.reponce.ResponseHandler;
//import com.home.insurance.service.MaritalStatusService;
//
//@RestController
//public class MaritalStatusController {
//	
//	@Autowired
//	private MaritalStatusService Service;
//	
//	@RequestMapping(value = "/status", method = RequestMethod.POST)
//	public MaritalStatus saveOrUpdate (@RequestBody MaritalStatus status)
//	{
//		MaritalStatus result = Service.saveStatus(status);
//		return result;
//	}
//	
//	@GetMapping("/marital")
//    public ResponseEntity<Object> Get(){
//            List<MaritalStatus> result = (List<MaritalStatus>) Service.getMaritalStatuss();
//          //  return new APIResponse<List<Lob>>(result.size(),result);
//        try {
//            if(result==null){
//           throw new ServiceNotFoundException("Record_Not_Found");
//            }
//         return  ResponseHandler.generateResponse("Successfully retrieved Data!",HttpStatus.OK,result);
//       }catch(Exception e){
//
//            return  ResponseHandler.generateResponse(e.getMessage(),HttpStatus.MULTI_STATUS,null);
//        }
//
//    }
//
//    @GetMapping("/marital/{marital_id}")
//    public ResponseEntity<Object> Get(@PathVariable int marital_id) {
//    	try{
//    		MaritalStatus result =  this.Service.getMaritalStatusByMaritalId(marital_id);
//    		
//    		if(result==null){
//    			throw new LobNotfoundException("Record_Not_Found");
//    		}
//    		return ResponseHandler.generateResponse("Successfully retrieved data!",HttpStatus.OK,result);
//    	}catch(LobNotfoundException e){
//    		return  ResponseHandler.generateResponse(e.getMessage(),HttpStatus.BAD_REQUEST,null);
//    	}
//
//    }
//
//}
