package com.home.insurance.service;

import java.util.List;

import com.home.insurance.bean.Property;

public interface PropertyService {

	List<Property> getPropertys();

	Property saveProper(Property proper);

	List<Property> findByProperId(int proper_id);

	//Property getUserByProperId(int proper_id);

}
