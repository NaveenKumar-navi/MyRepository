package com.home.insurance.dto;

import java.util.List;

import com.home.insurance.bean.City;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StateResponse {
	
	private Long id;
	
	private String state;
	
	private String description;
	
	private List<City> citys;
	
}