package com.home.insurance.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.home.insurance.bean.State;

public interface StateRepository extends JpaRepository<State,Integer>{

	State findById(int id);

}
