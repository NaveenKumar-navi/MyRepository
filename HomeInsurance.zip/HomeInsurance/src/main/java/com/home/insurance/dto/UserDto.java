package com.home.insurance.dto;

import java.util.List;

import com.home.insurance.bean.Plan;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDto {

	private int userId;
	private String firstName;
	private String lastName;
	private String email;
	private Long phoneNumber;
	//private List<PropertyDto> propertys; 
	
	
	private Long marketValue;
	private Long carpetAreasqft;
	private String schemeName;
	private String schemeYear;
	private List<Plan> plan;

}
