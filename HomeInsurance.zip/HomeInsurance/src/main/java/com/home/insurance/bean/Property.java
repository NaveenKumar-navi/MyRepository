package com.home.insurance.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table( name = "Property")
public class Property {
	
	@Id
	private int properId;
	private Long marketValue;
	private Long carpetAreasqft;
//	private int pinCodeId;
//	private Long ageBuliding;
//	private String cityLimits;
//	private String Address;
//	private String flatOrBunglow;
	private int userId;
}
