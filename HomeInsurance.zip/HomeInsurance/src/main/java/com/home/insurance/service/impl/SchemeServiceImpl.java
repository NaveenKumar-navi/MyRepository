package com.home.insurance.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.home.insurance.bean.Scheme;
import com.home.insurance.repository.SchemeRepository;
import com.home.insurance.service.SchemeService;

@Service
public class SchemeServiceImpl implements SchemeService{

	@Autowired
	private SchemeRepository repository;

//	@Override
//	public Coverage saveCoverage(Coverage coverage) {
//
//		return repository.save(coverage);
//	}

	@Override
	public Scheme saveScheme(Scheme scheme) {
		
		return repository.save(scheme);
	}

//	@Override
//	public Scheme getUserBySchemeId(int home_id) {
//		
//		return repository.findBySchemeId(home_id);
//	}

	@Override
	public List<Scheme> getSchemes() {
		
		return repository.findAll();
	}
}
