package com.home.insurance.service;

import java.util.List;
import com.home.insurance.bean.User;
import com.home.insurance.dto.UserDto;

public interface UserService {

	User saveUser(User user);

	List<User> getUsers();

	User getUserByUserId(int user_id);

	List<UserDto> findByUserId(int user_id);

	//UserDto getUserByUserId(int user_id, boolean propertyData);


}
