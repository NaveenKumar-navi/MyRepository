//package com.home.insurance.service.impl;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.home.insurance.bean.PinCode;
//import com.home.insurance.repository.PinCodeRepository;
//import com.home.insurance.service.PinCodeService;
//
//@Service
//public class PinCodeServiceImpl implements PinCodeService{
//	
//	@Autowired
//	private PinCodeRepository repository;
//
//	@Override
//	public PinCode savePin(PinCode code) {
//	
//		return repository.save(code);
//	}
//
//	@Override
//	public List<PinCode> getPinCodes() {
//
//		return repository.findAll();
//	}
//
//	@Override
//	public List<PinCode> getPinCodeByCityId(int city_id) {
//
//		return repository.findByCityId(city_id);
//	}
//
//}
