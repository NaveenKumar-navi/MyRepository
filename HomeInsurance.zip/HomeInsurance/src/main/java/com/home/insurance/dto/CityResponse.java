package com.home.insurance.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CityResponse {
	
	private Long id;
	
	private String state;
	
	private String description;
	
	private String cityName;
}
