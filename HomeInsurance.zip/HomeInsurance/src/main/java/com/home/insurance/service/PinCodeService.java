//package com.home.insurance.service;
//
//import java.util.List;
//
//import com.home.insurance.bean.PinCode;
//
//public interface PinCodeService {
//
//	PinCode savePin(PinCode code);
//
//	List<PinCode> getPinCodes();
//
//	List<PinCode> getPinCodeByCityId(int city_id);
//
//}
