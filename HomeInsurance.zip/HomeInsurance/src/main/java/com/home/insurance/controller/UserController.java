package com.home.insurance.controller;

import java.util.List;
import javax.management.ServiceNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.home.insurance.bean.User;
import com.home.insurance.dto.UserDto;
import com.home.insurance.exception.LobNotfoundException;
import com.home.insurance.reponce.ResponseHandler;
import com.home.insurance.service.UserService;



@RestController
public class UserController {
	
	@Autowired
	private UserService Service;
	
//	@Autowired
//	private UserRepository repo;
	
//	@RequestMapping(value = "/custemer", method = RequestMethod.POST)
//	public User saveOrUpdate (@RequestBody User user)
//	{
//		User result = Service.saveCustemer(user);
//		return result;
//	}
	
	 @PostMapping("/user")
	    public ResponseEntity<Object> Post(@RequestBody User user){
	        try{
	           User result = Service.saveUser(user);
	           return ResponseHandler.generateResponse("Successfully added data!",HttpStatus.OK,result);
	        }catch (Exception e){
	          return ResponseHandler.generateResponse(e.getMessage(),HttpStatus.MULTI_STATUS,null);
	        }
	    }

	    @GetMapping("/Users")
	    public ResponseEntity<Object> Get(){
	            List<User> result = (List<User>) Service.getUsers();
	          //  return new APIResponse<List<Lob>>(result.size(),result);
	        try {
	            if(result==null){
	           throw new ServiceNotFoundException("Record_Not_Found");
	            }
	         return  ResponseHandler.generateResponse("Successfully retrieved Data!",HttpStatus.OK,result);
	       }catch(Exception e){

	            return  ResponseHandler.generateResponse(e.getMessage(),HttpStatus.MULTI_STATUS,null);
	        }

	    }

//	    @GetMapping("/Users/{user_id}")
//	    public ResponseEntity<Object> Get(@PathVariable int user_id) {
//	    	try{
//	    		User
//	    		result =  this.Service.getUserByUserId(user_id);
//	    		
//	    		if(result==null){
//	    			throw new LobNotfoundException("Record_Not_Found");
//	    		}
//	    		return ResponseHandler.generateResponse("Successfully retrieved data!",HttpStatus.OK,result);
//	    	}catch(LobNotfoundException e){
//	    		return  ResponseHandler.generateResponse(e.getMessage(),HttpStatus.BAD_REQUEST,null);
//	    	}
	    	

		    @GetMapping("/User/{user_id}")
		    public ResponseEntity<Object> Get(@PathVariable int user_id) {
		    	try{
		    		List<UserDto>
		    		result =  this.Service.findByUserId(user_id);
		    		
		    		if(result==null){
		    			throw new LobNotfoundException("Record_Not_Found");
		    		}
		    		return ResponseHandler.generateResponse("Successfully retrieved data!",HttpStatus.OK,result);
		    	}catch(LobNotfoundException e){
		    		return  ResponseHandler.generateResponse(e.getMessage(),HttpStatus.BAD_REQUEST,null);
		    	}

	    }
//	    @GetMapping("/statesandcity")
//    	public List<UserDto> getData () {
//    		List<User> list = repo.findByUserId();
//    		List<UserDto> responseList = new ArrayList<>();
//    		
//    		list.forEach(l -> {
//    			UserDto response = new UserDto();
//    			response.setFirstName(l.getFirstName());s
//    			response.setLastName(l.getLastName());
//    			response.setPhoneNumber(l.getPhoneNumber());
//    			response.setEmail(l.getEmail());
////    			response.setId(l.getId());
////    			response.setState(l.getStateName());
////    			response.setDescription(l.getDescription());
//    			List<String> citys = new ArrayList<>();
//    			for (Property city : l.getCitys()) {
//    				citys.add(city.getCityName());
//    			}
//    			response.setCitys(citys);
//    			responseList.add(response);
//    		});
//    		return responseList;
//    	}
	    
//	    @GetMapping("/Alldata")
//		public List<UserDto> getByData() {
//
//			List<User> getall;
//			UserDto user = null;
//			List<UserDto> all = null;
//			all = new ArrayList<UserDto>();
//
//			try {
//				getall = repo.findByUserId();
//
//				for (UserDto lobObj : getall) {
//					user = new UserDto();
//					user.setFirstName(lobObj.getFirstName());
//					user.setLastName(lobObj.getFirstName());
//					user.setEmail(lobObj.getEmail());
//					user.setPhoneNumber(lobObj.getPhoneNumber());
//					user.setMarketValue(lobObj.getMarketValue());
//					user.setCarpetAreasqft(lobObj.getCarpetAreasqft());
//					user.setSchemeName(lobObj.getSchemeName());
//					user.setSchemeYear(lobObj.getSchemeYear());
//					user.setCost(lobObj.getCost());
//					user.setCoverAge(lobObj.getCoverAge());
//					user.setPlanName(lobObj.getPlanName());
//					all.add(user);
//				}
				
//				for(Property obj : mAppParameter) {
//					user.setMarketValue(obj.getMarketValue());
//					user.setCarpetAreasqft(obj.getCarpetAreasqft());
//					mAppParaList.add(user);
//				}

//			} catch (Exception ex) {
//				//log.error(ex);
//				return Collections.emptyList();
//			}
//			return all;
//
//		}
	    
//	    @GetMapping(value = "/{value}", produces = "application/json")
//		public ResponseEntity<?> getByCode(@RequestHeader HttpHeaders httpHeader, @PathVariable("userId") int user_id)
//				throws Exception {
//
//			try {
//
//				List<UserDto> result = Service.getByUserId(user_id);
//
//				return ResponseHandler.generateResponse("Successfully retrieved data!",HttpStatus.OK,result);
//
//			} catch (Exception e) {
//
//				e.printStackTrace();
//				return ResponseHandler.generateResponse(e.getMessage(),HttpStatus.BAD_REQUEST,null);
//			}
//		}

}
