//package com.home.insurance.controller;
//
//import java.util.List;
//
//import javax.management.ServiceNotFoundException;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.home.insurance.bean.PinCode;
//import com.home.insurance.exception.LobNotfoundException;
//import com.home.insurance.reponce.ResponseHandler;
//import com.home.insurance.service.PinCodeService;
//
//@RestController
//public class PinCodeController {
//
//	@Autowired
//	private PinCodeService Service;
//	
//	@RequestMapping(value = "/pincode", method = RequestMethod.POST)
//	public PinCode saveOrUpdate (@RequestBody PinCode code)
//	{
//		PinCode result = Service.savePin(code);
//		return result;
//	}
//	
//	@GetMapping("/pincodes")
//    public ResponseEntity<Object> Get(){
//            List<PinCode> result = (List<PinCode>) Service.getPinCodes();
//          //  return new APIResponse<List<Lob>>(result.size(),result);
//        try {
//            if(result==null){
//           throw new ServiceNotFoundException("Record_Not_Found");
//            }
//         return  ResponseHandler.generateResponse("Successfully retrieved Data!",HttpStatus.OK,result);
//       }catch(Exception e){
//
//            return  ResponseHandler.generateResponse(e.getMessage(),HttpStatus.MULTI_STATUS,null);
//        }
//
//    }
//
//    @GetMapping("/pincodes/{city_id}")
//    public ResponseEntity<Object> Get(@PathVariable int city_id) {
//    	try{
//    		List<PinCode> result =  (List<PinCode>) Service.getPinCodeByCityId(city_id);
//    		
//    		if(result==null){
//    			throw new LobNotfoundException("Record_Not_Found");
//    		}
//    		return ResponseHandler.generateResponse("Successfully retrieved data!",HttpStatus.OK,result);
//    	}catch(LobNotfoundException e){
//    		return  ResponseHandler.generateResponse(e.getMessage(),HttpStatus.BAD_REQUEST,null);
//    	}
//    }
//    
//    
//}
