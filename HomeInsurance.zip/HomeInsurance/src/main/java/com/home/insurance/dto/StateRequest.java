package com.home.insurance.dto;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class StateRequest {
	
	private String stateName;
	
	private String description;
	
	private List<String> citys;
	
	
}
