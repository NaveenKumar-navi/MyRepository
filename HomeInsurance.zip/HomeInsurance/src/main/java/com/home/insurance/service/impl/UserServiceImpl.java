package com.home.insurance.service.impl;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.home.insurance.bean.Plan;
import com.home.insurance.bean.Property;
import com.home.insurance.bean.Scheme;
import com.home.insurance.bean.User;
import com.home.insurance.dto.UserDto;
import com.home.insurance.repository.PlanRepository;
import com.home.insurance.repository.PropertyRepository;
import com.home.insurance.repository.SchemeRepository;
import com.home.insurance.repository.UserRepository;
import com.home.insurance.service.UserService;


@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepository repository;
	
	@Autowired
	private PropertyRepository repo;
	
	@Autowired
	private SchemeRepository schemerepo;
	
	@Autowired
	private PlanRepository planrepo;
	
//	@Override
//	public User saveCustemer(User user) {
//		return repository.save(user);
//	}

	@Override
	public User saveUser(User user) {
		
		return repository.save(user);
	}

	@Override
	public List<User> getUsers() {

		return repository.findAll();
	}

	@Override
	public User getUserByUserId(int user_id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<UserDto> findByUserId(int user_id) {
	
		User user = repository.findByUserId(user_id);
		Optional<Property> proper = repo.findById(user.getProperId());
		Optional<Scheme> scheme = schemerepo.findById(user.getSchemeId());
		
		Optional<Property> pro = null;
		List<UserDto> dto = null;
		
		dto = new ArrayList<UserDto>();
		
		pro = repo.findById(user.getProperId());
		//planlist = planrepo.findByPlanId(user.getPlanId());
//		List<User> list = repository.findAll();
//		List<UserDto> responseList = new ArrayList<>();
		
//		list.forEach(l -> {
//			UserDto response = new UserDto();
//			response.setFirstName(l.getFirstName());
//			response.setCarpetAreasqft(proper.get().getCarpetAreasqft());
//			response.setSchemeName(scheme.get().getSchemeName());
////			response.setCoverAge(l.getCoverAge())
////			response.setId(l.getId());
////			response.setState(l.getStateName());
////			response.setDescription(l.getDescription());
//			List<String> citys = new ArrayList<>();
//			for (Plan city : l.getPlan()) {
//				//citys.add(city.getCost());
//				citys.add(city.getCoverAge());
//				citys.add(city.getPlanName());
//				//citys.add(city.getCityName());
//			}
//			response.set(citys);
//			responseList.add(response);
//		});
//		return  responseList;
//	}		

		UserDto userdto = new UserDto();
		userdto.setUserId(user.getUserId());
		userdto.setFirstName(user.getFirstName());
		userdto.setLastName(user.getLastName());
		userdto.setEmail(user.getEmail());
		userdto.setPhoneNumber(user.getPhoneNumber());
		userdto.setCarpetAreasqft( proper.get().getCarpetAreasqft());
		userdto.setMarketValue(proper.get().getMarketValue());
		userdto.setSchemeYear(scheme.get().getSchemeYear());
		userdto.setSchemeName(scheme.get().getSchemeName());
		List<Plan> plans = new ArrayList<>();
		for(Plan plan : planrepo.findByUserId(user.getUserId())){
			Plan pl = new Plan();
			pl.setPlanId(plan.getPlanId());
			pl.setUserId(plan.getUserId());
			pl.setPlan(plan.getPlan());
			pl.setCost(plan.getCost());
			pl.setCoverAge(plan.getCoverAge());
			plans.add(pl);
		}
		userdto.setPlan(plans);
		dto.add(userdto);

	
		return dto;
	}
//	obj.setCost(((Plan).getCost());
//	obj.setCoverAge(((Plan) plan).getCoverAge());
//	obj.setPlanName(((Plan) plan).getPlanName())
 

//@GetMapping("/statesandcity")
//public List<UserDto> getData () {
//	List<User> list = planrepo.findAll();
//	List<UserDto> responseList = new ArrayList<>();
//	
//	list.forEach(l -> {
//		UserDto response = new UserDto();
//		response.setFirstName(l.getFirstName());
//		response.setCoverAge(l.getCoverAge())
//		response.setId(l.getId());
//		response.setState(l.getStateName());
//		response.setDescription(l.getDescription());
//		List<String> citys = new ArrayList<>();
//		for (Plan city : l.getPlan()) {
//			//citys.add(city.getCost());
//			citys.add(city.getCoverAge());
//			citys.add(city.getPlanName());
//			//citys.add(city.getCityName());
//		}
//		response.setPlanName(citys);
//		responseList.add(response);
//	});
//	return responseList;
//}
//	@Override
//    public userDto findBycusId(int cusId)
//    {
//        customerDetail cusobj = customerDetailRepository.findBycusId(cusId);
//        Optional<buyingHistory> buyobj1 = repo.findById(cusobj.getBuyingId());
//        Optional<mobileBrand> mobobj2 = repo1.findById(cusobj.getMobileBrandId());
//
//        Optional<mobileDetail> mobdetailObj3 = repo2.findById(cusobj.getModelId());
//
//        Optional<scheme> schemeObj = repo3.findById(cusobj.getSchemeId());
//
//       List<plans> planobj = repo4.findByplansId(cusobj.getPlanId());
//
//        //List<plans> list = repo4.findAll();
//
//        List<plans> myplan;
//        List<userDto> plist = null;
//
//        plist = new ArrayList<userDto>();
//
//        myplan = repo4.findByplansId(cusobj.getPlanId());
//
//        for(plans cuobj : myplan){
//
//       
//        }
//            userDto obj = new userDto();
//
//        obj.setCusId(cusobj.getCusId());
//        obj.setName(cusobj.getName());
//        obj.setDob(cusobj.getDob());
//        obj.setEmail(cusobj.getEmail());
//        obj.setMobileNo(cusobj.getMobileNo());
//        obj.setBuyingMonth(buyobj1.get().getBuyingMonth());
//     //  obj.setAmount(mplanlist.get().getAmount());
//        obj.setBrandName(mobobj2.get().getBrandName());
//        obj.setModelName(mobdetailObj3.get().getModelName());
//        obj.setRate(mobdetailObj3.get().getRate());
//        obj.setPlanName(obj.getPlanName());
//        obj.setAmount(obj.getAmount());
//        obj.setSchemeName(schemeObj.get().getSchemeName());
//
//       return obj;
//
//    }
	
//	@Override
//	public UserDto getUserByUserId(int user_id, boolean propertyData) {
//		User user;
//		List<Property> proper = null;
//		
//		user =repository.findByUserId(user_id);
//		if(propertyData) {
//			proper = repo.findAllByUserId(user_id);
//		}
//		
//		UserDto userDto = new UserDto();
//		
//		userDto.setUserId(user.getUserId());
//		userDto.setFirstName(user.getFirstName());
//		userDto.setLastName(user.getLastName());
//		userDto.setEmail(user.getEmail());
//		userDto.setPhoneNumber(user.getPhoneNumber());
//		
//		PropertyDto properDto = new PropertyDto();
//	
//		List<UserDto> authorDTOList = new ArrayList<>();
//        if (proper != null) {
//            for (Property property : proper) {
//                Property propertys = property
//                
//                UserDto userDt = new UserDto();
//			
//			properDto.setProperId(user_id);
//		}
//		
//		userDto.setPropertys(proper);

//		 public BookDTO getBookById(Long bookId, boolean authorData) {
//
//		        Book book;
//		        List<BookAuthor> bookAuthors = null;
//
//		        book = bookRepository.findOne(bookId);
//
//		        if (authorData) {
//		            bookAuthors = bookAuthorRepository.findAllByBookId(bookId);
//		        }
//
//		        BookDTO bookDTO = new BookDTO();
//
//		        // set book details
//		        bookDTO.setId(book.getId());
//		        bookDTO.setName(book.getName());
//		        bookDTO.setDesc(book.getDesc());
//		        bookDTO.setYearOfPublication(book.getYearOfPublication());
//		        bookDTO.setBookType(book.getBookType());
//
//		        // get author details
//		        List<AuthorDTO> authorDTOList = new ArrayList<>();
//		        if (bookAuthors != null) {
//		            for (BookAuthor bookAuthor : bookAuthors) {
//		                Author author = bookAuthor.getAuthor();
//
//		                AuthorDTO authorDTO = new AuthorDTO();
//		                authorDTO.setId(author.getId());
//		                authorDTO.setName(author.getName());
//		                authorDTO.setGender(author.getGender());
//
//		                authorDTOList.add(authorDTO);
//		            }
//
//		            // set author details
//		            bookDTO.setAuthors(authorDTOList);
//		        }
//		        return bookDTO;
//		    }
//	@Override
//	public List<UserDto> getByUserId(int user_id) {
//		
//		List<User> property;
//		UserDto Property = null;
//		List<UserDto> PropertyList = null;
//		PropertyList = new ArrayList<UserDto>();
//
//		try {
//			property = repository.findUserByUserId(user_id);
//
//			for (Property lobObj : ) {
//				Property = new UserDto();
//				Property.setCarpetAreasqft(lobObj.getCarpetAreasqft());
//				Property.setAgeBuliding(lobObj.getAgeBuliding());
//				Property.setMarketValue(lobObj.getMarketValue());
//				PropertyList.add(scheme);
//			}
//
//		} catch (Exception ex) {
//	
//			return Collections.emptyList();
//		}
//		return PropertyList;

//	public Product getProductByPsaf_sys_id(int psaf_sys_id){
//        return repository.findById(psaf_sys_id);
//    }
	
//	@Override
//	public User getUserByHomeId(int home_id) {
//		
//		return repository.findById(home_id);
//	}
	
	}

	