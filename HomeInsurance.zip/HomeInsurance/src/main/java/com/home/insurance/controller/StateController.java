package com.home.insurance.controller;

import java.util.ArrayList;
import java.util.List;

import javax.management.ServiceNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.home.insurance.bean.City;
import com.home.insurance.bean.State;
import com.home.insurance.dto.StateResponse;
import com.home.insurance.exception.LobNotfoundException;
import com.home.insurance.reponce.ResponseHandler;
import com.home.insurance.repository.CityRepository;
import com.home.insurance.repository.StateRepository;
import com.home.insurance.service.StateService;

@RestController
public class StateController {
	
	@Autowired
	private StateService Service;
	
	@Autowired
	private StateRepository repo;
	
	@Autowired
	private CityRepository repoCity;
	
	@RequestMapping(value = "/state", method = RequestMethod.POST)
	public State saveOrUpdate (@RequestBody State state)
	{
		State result = Service.saveState(state);
		return result;
	}
	
	@GetMapping("/states")
    public ResponseEntity<Object> Get(){
            List<State> result = (List<State>) Service.getStates();

        try {
            if(result==null){
           throw new ServiceNotFoundException("Record_Not_Found");
            }
         return  ResponseHandler.generateResponse("Successfully retrieved Data!",HttpStatus.OK,result);
       }catch(Exception e){

            return  ResponseHandler.generateResponse(e.getMessage(),HttpStatus.MULTI_STATUS,null);
        }

    }

    @GetMapping("/state/{id}")
    public ResponseEntity<Object> Get(@PathVariable int id) {
    	try{
    		State result =  this.Service.getStateByStateId(id);
    		
    		if(result==null){
    			throw new LobNotfoundException("Record_Not_Found");
    		}
    		return ResponseHandler.generateResponse("Successfully retrieved data!",HttpStatus.OK,result);
    	}catch(LobNotfoundException e){
    		return  ResponseHandler.generateResponse(e.getMessage(),HttpStatus.BAD_REQUEST,null);
    	}
    }
    
    @GetMapping("/statesandcity")
	public List<StateResponse> getData () {
		List<State> list = repo.findAll();
		List<StateResponse> responseList = new ArrayList<>();
		
		list.forEach(l -> {
			StateResponse response = new StateResponse();
			response.setId(l.getId());
			response.setState(l.getStateName());
			response.setDescription(l.getDescription());
			List<City> citys = new ArrayList<>();
			for (City city : repoCity.findByStateId(l.getId())) {
				
				City obj = new City();
				obj.setCityName(city.getCityName());
				obj.setId(city.getId());
				obj.setState(city.getState());
				
		
				citys.add(obj);
			}
			response.setCitys(citys);
			responseList.add(response);
		});
		return responseList;
	}
}

//    	@GetMapping("/statesandcity")
//    	public List<StateResponse> getData () {
//    		List<State> list = repo.findAll();
//    		List<StateResponse> responseList = new ArrayList<>();
//    		
//    		list.forEach(l -> {
//    			StateResponse response = new StateResponse();
//    			response.setId(l.getId());
//    			response.setState(l.getStateName());
//    			response.setDescription(l.getDescription());
//    			List<String> citys = new ArrayList<>();
//    			for (City city : l.getCitys()) {
//    				citys.add(city.getCityName());
//    			}
//    			response.setCitys(citys);
//    			responseList.add(response);
//    		});
//    		return responseList;
//    	}
//
//    }

