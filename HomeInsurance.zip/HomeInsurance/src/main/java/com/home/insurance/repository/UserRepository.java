package com.home.insurance.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.home.insurance.bean.User;

@Repository
public interface UserRepository extends JpaRepository<User,Integer>{

	User findByUserId(int user_id);

	List<User> findUserByUserId(int user_id);



	

}
