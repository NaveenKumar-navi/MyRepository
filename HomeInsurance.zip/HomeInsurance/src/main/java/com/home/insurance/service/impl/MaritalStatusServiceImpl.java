//package com.home.insurance.service.impl;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.home.insurance.bean.MaritalStatus;
//import com.home.insurance.repository.MaritalStatusRepository;
//import com.home.insurance.service.MaritalStatusService;
//
//@Service
//public class MaritalStatusServiceImpl implements MaritalStatusService{
//
//	@Autowired
//	private MaritalStatusRepository repository;
//
//	@Override
//	public MaritalStatus saveStatus(MaritalStatus status) {
//		
//		return repository.save(status);
//	}
//
//	@Override
//	public MaritalStatus getMaritalStatusByMaritalId(int marital_id) {
//
//		return repository.findByMaritalId(marital_id);
//	}
//
//	@Override
//	public List<MaritalStatus> getMaritalStatuss() {
//		
//		return repository.findAll();
//	}
//}
