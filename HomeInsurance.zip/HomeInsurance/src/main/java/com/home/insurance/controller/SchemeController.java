package com.home.insurance.controller;

import java.util.List;

import javax.management.ServiceNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.home.insurance.bean.Scheme;
import com.home.insurance.bean.User;
import com.home.insurance.exception.LobNotfoundException;
import com.home.insurance.reponce.ResponseHandler;
import com.home.insurance.service.SchemeService;

@RestController
public class SchemeController {
	
	@Autowired
	private SchemeService Service;

//	@RequestMapping(value = "/coverage", method = RequestMethod.POST)
//	public Coverage saveOrUpdate (@RequestBody Coverage coverage)
//	{
//		Coverage result = Service.saveCoverage(coverage);
//		return result;
//	}
	
	 @PostMapping("/cover")
	    public ResponseEntity<Object> Post(@RequestBody Scheme scheme){
	        try{
	        	Scheme result = Service.saveScheme(scheme);
	           return ResponseHandler.generateResponse("Successfully added data!",HttpStatus.OK,result);
	        }catch (Exception e){
	          return ResponseHandler.generateResponse(e.getMessage(),HttpStatus.MULTI_STATUS,null);
	        }
	    }

	    @GetMapping("/covers")
	    public ResponseEntity<Object> Get(){
	            List<Scheme> result = (List<Scheme>) Service.getSchemes();
	          //  return new APIResponse<List<Lob>>(result.size(),result);
	        try {
	            if(result==null){
	           throw new ServiceNotFoundException("Record_Not_Found");
	            }
	         return  ResponseHandler.generateResponse("Successfully retrieved Data!",HttpStatus.OK,result);
	       }catch(Exception e){

	            return  ResponseHandler.generateResponse(e.getMessage(),HttpStatus.MULTI_STATUS,null);
	        }

	    }

//	    @GetMapping("/cover/{scheme_id}")
//	    public ResponseEntity<Object> Get(@PathVariable int scheme_id) {
//	    	try{
//	    		Scheme result =  this.Service.getUserBySchemeId(scheme_id);
//	    		
//	    		if(result==null){
//	    			throw new LobNotfoundException("Record_Not_Found");
//	    		}
//	    		return ResponseHandler.generateResponse("Successfully retrieved data!",HttpStatus.OK,result);
//	    	}catch(LobNotfoundException e){
//	    		return  ResponseHandler.generateResponse(e.getMessage(),HttpStatus.BAD_REQUEST,null);
//	    	}
//
//	    }
}


