package com.home.insurance.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.home.insurance.bean.Property;

@Repository
public interface PropertyRepository extends JpaRepository<Property,Integer>{

	List<Property> findByProperId(int proper_id);

	//List<Property> findAllByUserId(int user_id);

	//List<Property> findAllById(int properId);

}
