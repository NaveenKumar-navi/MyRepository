package com.home.insurance.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.home.insurance.bean.Plan;
import com.home.insurance.repository.PlanRepository;
import com.home.insurance.service.PlanService;

@Service
public class PlanServiceImpl implements PlanService{

	@Autowired
	private PlanRepository repository;
	
	@Override
	public Plan savePlan(Plan plan) {
		
		return repository.save(plan);
	}

	@Override
	public List<Plan> getPlans() {
		
		return repository.findAll();
	}

//	@Override
//	public List<Plan> getPlanByPlanId(List<Integer> plan_id) {
//		
//		return repository.findByPlanId(plan_id);
//	}

	@Override
	public Plan getPlanByPlanId(int plan_id) {
		// TODO Auto-generated method stub
		return null;
	}

}
