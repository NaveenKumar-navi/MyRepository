package com.home.insurance.controller;

import java.util.ArrayList;
import java.util.List;

import javax.management.ServiceNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.home.insurance.bean.City;
import com.home.insurance.bean.State;
import com.home.insurance.dto.CityResponse;
import com.home.insurance.dto.StateResponse;
import com.home.insurance.exception.LobNotfoundException;
import com.home.insurance.reponce.ResponseHandler;
import com.home.insurance.repository.CityRepository;
import com.home.insurance.service.CityService;

@RestController
public class CityController {

	@Autowired
	private CityService Service;
	
	@Autowired
	private CityRepository repo;
	
	@RequestMapping(value = "/city", method = RequestMethod.POST)
	public City saveOrUpdate (@RequestBody City city)
	{
		City result = Service.saveCity(city);
		return result;
	}
	
	 @GetMapping("/citys")
	    public ResponseEntity<Object> Get(){
	            List<City> result = (List<City>) Service.getCitys();

	        try {
	            if(result==null){
	           throw new ServiceNotFoundException("Record_Not_Found");
	            }
	         return  ResponseHandler.generateResponse("Successfully retrieved Data!",HttpStatus.OK,result);
	       }catch(Exception e){

	            return  ResponseHandler.generateResponse(e.getMessage(),HttpStatus.MULTI_STATUS,null);
	        }

	    }

	    @GetMapping("/citys/{id}")
	    public ResponseEntity<Object> Get(@PathVariable int id) {
	    	try{
	    		List<City> result = (List<City>) Service.getCityByStateId(id);
	    		
	    		if(result==null){
	    			throw new LobNotfoundException("Record_Not_Found");
	    		}
	    		return ResponseHandler.generateResponse("Successfully retrieved data!",HttpStatus.OK,result);
	    	}catch(LobNotfoundException e){
	    		return  ResponseHandler.generateResponse(e.getMessage(),HttpStatus.BAD_REQUEST,null);
	    	}

	    }
	    
	    @GetMapping("/citysandstate")
		public List<CityResponse> getCitys () {
			List<City> list = repo.findAll();
			List<CityResponse> responseList = new ArrayList<>();
			list.forEach(c -> {
				CityResponse response = new CityResponse();
				response.setId(c.getId());
				response.setState(c.getState().getStateName());
				response.setDescription(c.getState().getDescription());
				response.setCityName(c.getCityName());
				responseList.add(response);
			});
			return responseList;
		}
	    
//	    @GetMapping("/statesandcity")
//    	public List<StateResponse> getData () {
//    		List<City> list = repo.findAll();
//    		List<CityResponse> responseList = new ArrayList<>();
//    		
//    		list.forEach(l -> {
//    			CityResponse response = new CityResponse();
//    			response.setCityName(l.getCityName())
//    			
//    			List<String> pins = new ArrayList<>();
//    			for (PinCode pin : l()) {
//    				pins.add(pin.getPinCode());
//    			}
//    			response.setPins(pins);
//    			responseList.add(response);
//    		});
//    		return responseList;
//    	}
}
