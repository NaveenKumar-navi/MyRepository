package com.home.insurance.service;

import java.util.List;

import com.home.insurance.bean.Plan;

public interface PlanService {

	Plan savePlan(Plan plan);

	List<Plan> getPlans();

	Plan getPlanByPlanId(int plan_id);

	//List<Plan> getPlanByPlanId(List<Integer> plan_id);

}
