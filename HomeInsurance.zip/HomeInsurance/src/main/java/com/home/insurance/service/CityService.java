package com.home.insurance.service;

import java.util.List;

import com.home.insurance.bean.City;

public interface CityService {

	City saveCity(City city);

	List<City> getCitys();

	List<City> getCityByStateId(int id);

}
