//package com.home.insurance.repository;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.home.insurance.bean.Gender;
//
//public interface GenderRepository extends JpaRepository<Gender,Integer>{
//
//	Gender findByGenderId(int gender_id);
//
//}
