package com.home.insurance.service;

import java.util.List;

import com.home.insurance.bean.State;

public interface StateService {

	State saveState(State state);

	List<State> getStates();

	State getStateByStateId(int id);

}
