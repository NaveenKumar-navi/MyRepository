package com.home.insurance.bean;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table( name = "user")
public class User {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int userId;
	private String firstName;
	private String lastName;
	private String email;
	private Long phoneNumber;
	private int  properId;
	private int schemeId;
	@ElementCollection
	@Column(name="planId")
	private List<Integer> plan;
	
//	private String addressLine1;
//	private String addressLine2;
//	private int genderId;
//	private int maritalStatusId;
//	private int cityId;
//	private int stateId;
//	private int pinCodeId;
	
}