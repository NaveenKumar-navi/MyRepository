//package com.home.insurance.service.impl;
//
//
//
//import com.Insurance.Dto.userDto;
//import com.Insurance.Repository.*;
//import com.Insurance.Service.customerDetailService;
//import com.Insurance.beans.*;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.repository.CrudRepository;
//import org.springframework.stereotype.Service;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//@Service
//public class customerDetailServiceImpl implements customerDetailService {
//
//     @Autowired
//    private customerDetailRepository customerDetailRepository;
//     @Autowired
//     private buyingHistoryRepository repo;
//
//    @Autowired
//    private mobileBrandRepository repo1;
//
//    @Autowired
//    private mobileDetailRepository repo2;
//
//    @Autowired
//    private schemeRepository repo3;
//
//
//    @Autowired
//    private plansRepository repo4;
//
//
//    @Override
//    public List<customerDetail> saveCustomer(List<customerDetail> customerDetails) {
//
//
//        return customerDetailRepository.saveAll(customerDetails);
//    }
//
//    @Override
//    public List<customerDetail> getCustomerDetails() {
//        return customerDetailRepository.findAll();
//    }
//
//    @Override
//    public userDto findBycusId(int cusId)
//    {
//        customerDetail cusobj = customerDetailRepository.findBycusId(cusId);
//        Optional<buyingHistory> buyobj1 = repo.findById(cusobj.getBuyingId());
//        Optional<mobileBrand> mobobj2 = repo1.findById(cusobj.getMobileBrandId());
//
//        Optional<mobileDetail> mobdetailObj3 = repo2.findById(cusobj.getModelId());
//
//        Optional<scheme> schemeObj = repo3.findById(cusobj.getSchemeId());
//
//       List<plans> planobj = repo4.findByplansId(cusobj.getPlanId());
//
//        //List<plans> list = repo4.findAll();
//
//        List<plans> myplan;
//        List<userDto> plist = null;
//
//        plist = new ArrayList<userDto>();
//
//        myplan = repo4.findByplansId(cusobj.getPlanId());
//
//        for(plans cuobj : myplan){
//
//       
//        }
//
//
//
//            userDto obj = new userDto();
//
//        obj.setCusId(cusobj.getCusId());
//        obj.setName(cusobj.getName());
//        obj.setDob(cusobj.getDob());
//        obj.setEmail(cusobj.getEmail());
//        obj.setMobileNo(cusobj.getMobileNo());
//        obj.setBuyingMonth(buyobj1.get().getBuyingMonth());
//     //  obj.setAmount(mplanlist.get().getAmount());
//        obj.setBrandName(mobobj2.get().getBrandName());
//        obj.setModelName(mobdetailObj3.get().getModelName());
//        obj.setRate(mobdetailObj3.get().getRate());
//        obj.setPlanName(obj.getPlanName());
//        obj.setAmount(obj.getAmount());
//        obj.setSchemeName(schemeObj.get().getSchemeName());
//
//       return obj;
//
//    }
//
//
//
//
//    @Override
//    public String deleteCustomerId(int cusId) {
//        return customerDetailRepository.deleteBycusId(cusId);
//    }
//
//    @Override
//    public List<userDto> getBycusId(String value) {
//
//        List<userDto> user;
//        userDto users = null;
//        List<userDto> usersList = null;
//        usersList = new ArrayList<userDto>();
//
//        user = customerDetailRepository.findByCusId(value);
//
//        for (userDto cusObj : user ){
//            users = new userDto();
//            users.setCusId(cusObj.getCusId());
//            users.setName(cusObj.getName());
//            users.setDob(cusObj.getDob());
//            users.setEmail(cusObj.getEmail());
//            users.setMobileNo(cusObj.getMobileNo());
//            users.setBuyingMonth(cusObj.getBuyingMonth());
//            users.setAmount(cusObj.getAmount());
//            users.setBrandName(cusObj.getBrandName());
//            users.setModelName(cusObj.getModelName());
//            users.setRate(cusObj.getRate());
//            users.setPlanName(cusObj.getPlanName());
//            users.setAmount(cusObj.getAmount());
//            users.setSchemeName(cusObj.getSchemeName());
//            usersList.add(users);
//        }
//        return usersList;
//    }
//
//    @Override
//    public List<userDto> getBycusId(int cusId) {
//        return customerDetailRepository.findByCusId(cusId);
//    }
//
//
//}
