//package com.home.insurance.repository;
//
//import java.util.List;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.home.insurance.bean.PinCode;
//
//public interface PinCodeRepository extends JpaRepository<PinCode,Integer>{
//
//	List<PinCode> findByCityId(int city_id);
//
//}
