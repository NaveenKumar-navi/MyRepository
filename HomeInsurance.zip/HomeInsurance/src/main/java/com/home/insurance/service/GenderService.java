//package com.home.insurance.service;
//
//import java.util.List;
//
//import com.home.insurance.bean.Gender;
//
//public interface GenderService {
//
//	Gender saveGender(Gender gender);
//
//	List<Gender> getGenders();
//
//	Gender getGenderByGenderId(int gender_id);
//
//}
