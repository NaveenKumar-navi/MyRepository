//package com.home.insurance.repository;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.home.insurance.bean.MaritalStatus;
//
//public interface MaritalStatusRepository extends JpaRepository<MaritalStatus,Integer>{
//
//	MaritalStatus findByMaritalId(int marital_id);
//
//}
