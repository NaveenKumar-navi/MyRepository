//package com.home.insurance.service;
//
//import java.util.List;
//
//import com.home.insurance.bean.MaritalStatus;
//
//public interface MaritalStatusService {
//
//	MaritalStatus saveStatus(MaritalStatus status);
//
//	MaritalStatus getMaritalStatusByMaritalId(int marital_id);
//
//	List<MaritalStatus> getMaritalStatuss();
//
//}
