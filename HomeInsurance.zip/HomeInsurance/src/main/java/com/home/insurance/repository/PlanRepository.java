package com.home.insurance.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.home.insurance.bean.City;
import com.home.insurance.bean.Plan;

public interface PlanRepository extends JpaRepository<Plan,Integer>{

	List<Plan> findByUserId(int userId);


	//List<Plan> findAllById(List<Plan> plan);

//	List<Plan> findByPlanId(List<Integer> list);
//
//	List<Plan> findById(List<Integer> plan_id);
//	

}
