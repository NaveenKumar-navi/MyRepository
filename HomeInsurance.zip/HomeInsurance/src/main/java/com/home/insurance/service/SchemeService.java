package com.home.insurance.service;

import java.util.List;

import com.home.insurance.bean.Scheme;



public interface SchemeService {

	Scheme saveScheme(Scheme scheme);

	List<Scheme> getSchemes();

	//Scheme getUserBySchemeId(int scheme_id);

}
