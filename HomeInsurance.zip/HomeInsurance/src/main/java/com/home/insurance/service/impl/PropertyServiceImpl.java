package com.home.insurance.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.home.insurance.bean.Property;
import com.home.insurance.repository.PropertyRepository;
import com.home.insurance.service.PropertyService;

@Service
public class PropertyServiceImpl implements PropertyService{

	@Autowired
	private PropertyRepository repository;

	@Override
	public Property saveProper(Property proper) {
		
		return repository.save(proper);
	}

	@Override
	public List<Property> getPropertys() {
		
		return repository.findAll();
	}

	@Override
	public List<Property> findByProperId(int proper_id) {
		
		return repository.findByProperId(proper_id);
	}

//	@Override
//	public Property getUserByProperId(int proper_id) {
//		
//		return repository.findByProperId(proper_id);
	//}
}
