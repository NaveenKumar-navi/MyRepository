package com.home.insurance.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.home.insurance.bean.Scheme;


@Repository
public interface SchemeRepository extends JpaRepository<Scheme,Integer>{

	List<Scheme> findBySchemeId(int scheme_id);

	//Scheme findAllById(int schemeId);

}
