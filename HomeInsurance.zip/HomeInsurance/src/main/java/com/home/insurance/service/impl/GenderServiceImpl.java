//package com.home.insurance.service.impl;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.home.insurance.bean.Gender;
//import com.home.insurance.repository.GenderRepository;
//import com.home.insurance.service.GenderService;
//
//@Service
//public class GenderServiceImpl implements GenderService{
//
//	@Autowired
//	private GenderRepository repository;
//
//	@Override
//	public Gender saveGender(Gender gender) {
//
//		return repository.save(gender);
//	}
//
//	@Override
//	public List<Gender> getGenders() {
//		
//		return repository.findAll();
//	}
//
//	@Override
//	public Gender getGenderByGenderId(int gender_id) {
//
//		return repository.findByGenderId(gender_id);
//	}
//}
