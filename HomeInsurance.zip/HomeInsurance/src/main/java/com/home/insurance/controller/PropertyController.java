package com.home.insurance.controller;

import java.util.List;

import javax.management.ServiceNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.home.insurance.bean.Property;
import com.home.insurance.bean.User;
import com.home.insurance.exception.LobNotfoundException;
import com.home.insurance.reponce.ResponseHandler;
import com.home.insurance.service.PropertyService;

@RestController
public class PropertyController {

	@Autowired
	private PropertyService Service;
	
//	@RequestMapping(value = "/structure", method = RequestMethod.POST)
//	public Structure saveOrUpdate (@RequestBody Structure stru)
//	{
//		Structure result = Service.saveStructure(stru);
//		return result;
//	}
	
	 @PostMapping("/proper")
	    public ResponseEntity<Object> Post(@RequestBody Property proper){
	        try{
	        	Property result = Service.saveProper(proper);
	           return ResponseHandler.generateResponse("Successfully added data!",HttpStatus.OK,result);
	        }catch (Exception e){
	          return ResponseHandler.generateResponse(e.getMessage(),HttpStatus.MULTI_STATUS,null);
	        }
	    }

	    @GetMapping("/proper")
	    public ResponseEntity<Object> Get(){
	            List<Property> result = this.Service.getPropertys();
	            
	        try {
	            if(result==null){
	           throw new ServiceNotFoundException("Record_Not_Found");
	            }
	         return  ResponseHandler.generateResponse("Successfully retrieved Data!",HttpStatus.OK,result);
	       }catch(Exception e){

	            return  ResponseHandler.generateResponse(e.getMessage(),HttpStatus.MULTI_STATUS,null);
	        }

	    }
	    
	    @GetMapping("/prope/{proper_id}")
	    public ResponseEntity<Object> GetbyId(@PathVariable int proper_id){
	            List<Property> result = this.Service.findByProperId(proper_id);
	            
	        try {
	            if(result==null){
	           throw new ServiceNotFoundException("Record_Not_Found");
	            }
	         return  ResponseHandler.generateResponse("Successfully retrieved Data!",HttpStatus.OK,result);
	       }catch(Exception e){

	            return  ResponseHandler.generateResponse(e.getMessage(),HttpStatus.MULTI_STATUS,null);
	        }

	    }

//	    @GetMapping("/proper/{proper_id}")
//	    public ResponseEntity<Object> Get(@PathVariable int proper_id) {
//	    	try{
//	    		Property result =  this.Service.getUserByProperId(proper_id);
//	    		
//	    		if(result==null){
//	    			throw new LobNotfoundException("Record_Not_Found");
//	    		}
//	    		return ResponseHandler.generateResponse("Successfully retrieved data!",HttpStatus.OK,result);
//	    	}catch(LobNotfoundException e){
//	    		return  ResponseHandler.generateResponse(e.getMessage(),HttpStatus.BAD_REQUEST,null);
//	    	}
//
//	    }
}

