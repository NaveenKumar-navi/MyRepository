package com.home.insurance.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.home.insurance.bean.City;
import com.home.insurance.repository.CityRepository;
import com.home.insurance.service.CityService;

@Service
public class CityServiceImpl implements CityService{

	@Autowired
	private CityRepository repository;

	@Override
	public City saveCity(City city) {
		
		return repository.save(city);
	}

	@Override
	public List<City> getCitys() {
		
		return repository.findAll();
	}

	@Override
	public List<City> getCityByStateId(int id) {
		
		return repository.findById(id);
	}
}
